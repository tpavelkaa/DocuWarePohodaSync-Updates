param(
    [string]$InstallDirectory = "C:\Program Files\DocuWarePohodaSync",
    [string]$ServiceName = "DocuWarePohodaSync",
    [switch]$InstallService,
    [switch]$NoRestartService,
    [switch]$OverwriteMappings
)

$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)

    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Run this script from an elevated PowerShell session."
    }
}

function Resolve-FullPath([string]$Path) {
    return [System.IO.Path]::GetFullPath($Path)
}

function Test-SamePath {
    param(
        [string]$Left,
        [string]$Right
    )

    return (Resolve-FullPath $Left).TrimEnd(
        [System.IO.Path]::DirectorySeparatorChar,
        [System.IO.Path]::AltDirectorySeparatorChar
    ).Equals(
        (Resolve-FullPath $Right).TrimEnd(
            [System.IO.Path]::DirectorySeparatorChar,
            [System.IO.Path]::AltDirectorySeparatorChar
        ),
        [StringComparison]::OrdinalIgnoreCase)
}

function Copy-FileIfDifferent {
    param(
        [string]$Source,
        [string]$Destination
    )

    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        return
    }

    if (Test-SamePath -Left $Source -Right $Destination) {
        return
    }

    Copy-Item -LiteralPath $Source -Destination $Destination -Force
}

function Copy-DirectoryContent {
    param(
        [string]$Source,
        [string]$Destination,
        [bool]$Overwrite
    )

    if (-not (Test-Path -LiteralPath $Source -PathType Container)) {
        return
    }

    if (Test-SamePath -Left $Source -Right $Destination) {
        return
    }

    New-Item -ItemType Directory -Path $Destination -Force | Out-Null

    foreach ($item in Get-ChildItem -LiteralPath $Source -Force) {
        $target = Join-Path $Destination $item.Name

        if ($item.PSIsContainer) {
            Copy-DirectoryContent -Source $item.FullName -Destination $target -Overwrite $Overwrite
            continue
        }

        if ((Test-Path -LiteralPath $target) -and -not $Overwrite) {
            continue
        }

        Copy-Item -LiteralPath $item.FullName -Destination $target -Force
    }
}

Assert-Administrator

$packageDirectory = Resolve-FullPath $PSScriptRoot
$installDirectoryFullPath = Resolve-FullPath $InstallDirectory
$sourceExePath = Join-Path $packageDirectory "DocuWarePohodaSync.exe"
$targetExePath = Join-Path $installDirectoryFullPath "DocuWarePohodaSync.exe"

if (-not (Test-Path -LiteralPath $sourceExePath -PathType Leaf)) {
    throw "Package does not contain DocuWarePohodaSync.exe."
}

$existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
$wasRunning = $existingService -and $existingService.Status -eq "Running"

if ($existingService -and $wasRunning) {
    Stop-Service -Name $ServiceName -ErrorAction Stop
    $existingService.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(60))
}

New-Item -ItemType Directory -Path $installDirectoryFullPath -Force | Out-Null
Copy-FileIfDifferent -Source $sourceExePath -Destination $targetExePath

$templateSourcePath = Join-Path $packageDirectory "appsettings.template.json"
$templateTargetPath = Join-Path $installDirectoryFullPath "appsettings.template.json"
$settingsTargetPath = Join-Path $installDirectoryFullPath "appsettings.json"

if (Test-Path -LiteralPath $templateSourcePath -PathType Leaf) {
    Copy-FileIfDifferent -Source $templateSourcePath -Destination $templateTargetPath

    if (-not (Test-Path -LiteralPath $settingsTargetPath -PathType Leaf)) {
        Copy-Item -LiteralPath $templateSourcePath -Destination $settingsTargetPath -Force
    }
}

Copy-DirectoryContent `
    -Source (Join-Path $packageDirectory "PohodaTemplates") `
    -Destination (Join-Path $installDirectoryFullPath "PohodaTemplates") `
    -Overwrite $true

Copy-DirectoryContent `
    -Source (Join-Path $packageDirectory "Mappings") `
    -Destination (Join-Path $installDirectoryFullPath "Mappings") `
    -Overwrite ([bool]$OverwriteMappings)

$manifestPath = Join-Path $packageDirectory "release-manifest.json"
if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
    Copy-FileIfDifferent -Source $manifestPath -Destination (Join-Path $installDirectoryFullPath "release-manifest.json")
}

$updateSourcePath = Join-Path $packageDirectory "update-source.json"
if (Test-Path -LiteralPath $updateSourcePath -PathType Leaf) {
    Copy-FileIfDifferent -Source $updateSourcePath -Destination (Join-Path $installDirectoryFullPath "update-source.json")
}

if ($InstallService) {
    Push-Location $installDirectoryFullPath
    try {
        & $targetExePath --install-service

        if ($LASTEXITCODE -ne 0) {
            throw "Service installation failed with exit code $LASTEXITCODE."
        }
    }
    finally {
        Pop-Location
    }
}

$serviceAfterCopy = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue

if ($serviceAfterCopy -and -not $NoRestartService -and ($wasRunning -or $InstallService)) {
    Start-Service -Name $ServiceName -ErrorAction Stop
}

Write-Host "DocuWare Pohoda Sync was installed or updated in '$installDirectoryFullPath'."
Write-Host "Existing appsettings.json and mapping files were preserved."
